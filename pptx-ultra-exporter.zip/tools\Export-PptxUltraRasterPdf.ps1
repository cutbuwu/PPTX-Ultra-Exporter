<#
.SYNOPSIS
Exports a PPTX to a high-resolution raster PDF without lossy image recompression.

.DESCRIPTION
This tool avoids PowerPoint's native PDF compressor by:

1. Opening the deck in PowerPoint.
2. Exporting each slide as a high-resolution PNG.
3. Building a PDF from those PNGs with raw RGB image streams by default.

The output PDF is no longer editable/vector. It is designed for visual fidelity:
the PDF pages are high-resolution slide images.

.EXAMPLE
.\Export-PptxUltraRasterPdf.ps1 -PptxPath "C:\Decks\deck.pptx"

.EXAMPLE
.\Export-PptxUltraRasterPdf.ps1 -PptxPath "C:\Decks\deck.pptx" -Dpi 1200 -Compression Raw

.EXAMPLE
.\Export-PptxUltraRasterPdf.ps1 -PptxPath "C:\Decks\deck.pptx" -Compression Flate
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$PptxPath,

    [Parameter(Mandatory = $false, Position = 1)]
    [string]$PdfPath,

    [ValidateRange(72, 2400)]
    [int]$Dpi = 600,

    [ValidateSet("Raw", "Flate")]
    [string]$Compression = "Raw",

    [ValidateRange(1, 100)]
    [int]$TotalPortions = 1,

    [ValidateRange(1, 100)]
    [int]$KeepPortion = 1,

    [string]$PythonPath = "C:\Users\tumo0\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe",

    [switch]$KeepSlidePngs,

    [switch]$Visible,

    [switch]$OpenAfterExport
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Resolve-ExistingFile {
    param([Parameter(Mandatory = $true)][string]$Path)

    $item = Get-Item -LiteralPath $Path -ErrorAction Stop
    if ($item.PSIsContainer) {
        throw "Expected a file, but got a directory: $Path"
    }

    return $item.FullName
}

function Get-DefaultPdfPath {
    param([Parameter(Mandatory = $true)][string]$ResolvedPptxPath)

    $directory = Split-Path -Parent $ResolvedPptxPath
    $name = [System.IO.Path]::GetFileNameWithoutExtension($ResolvedPptxPath)
    return Join-Path $directory "$name.ultra-raster-${Dpi}dpi.pdf"
}

function New-WorkDirectory {
    param([Parameter(Mandatory = $true)][string]$ResolvedPptxPath)

    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($ResolvedPptxPath)
    $safeBaseName = ($baseName -replace '[^A-Za-z0-9_.-]', '_')
    $root = Join-Path ([System.IO.Path]::GetTempPath()) "pptx-ultra-raster-pdf"
    $name = "$safeBaseName-$Dpi-dpi-$(Get-Date -Format yyyyMMdd-HHmmss)"
    $path = Join-Path $root $name
    New-Item -ItemType Directory -Path $path -Force | Out-Null
    return $path
}

function Export-SlidesToPng {
    param(
        [Parameter(Mandatory = $true)][string]$ResolvedPptxPath,
        [Parameter(Mandatory = $true)][string]$SlidesDir
    )

    [int]$msoFalse = 0
    [int]$msoTrue = -1
    $withWindow = if ($Visible) { $msoTrue } else { $msoFalse }
    $powerPoint = $null
    $presentation = $null

    try {
        $powerPoint = New-Object -ComObject PowerPoint.Application
        if ($Visible) {
            $powerPoint.Visible = $msoTrue
        }

        $presentation = $powerPoint.Presentations.Open(
            $ResolvedPptxPath,
            $msoTrue,
            $msoFalse,
            $withWindow
        )

        $pageWidthPoints = [double]$presentation.PageSetup.SlideWidth
        $pageHeightPoints = [double]$presentation.PageSetup.SlideHeight
        [int]$pixelWidth = [math]::Round(($pageWidthPoints / 72.0) * $Dpi)
        [int]$pixelHeight = [math]::Round(($pageHeightPoints / 72.0) * $Dpi)

        if ($pixelWidth -le 0 -or $pixelHeight -le 0) {
            throw "Could not calculate slide export dimensions."
        }

        Write-Host "Slide size: $([math]::Round($pageWidthPoints / 72.0, 3)) x $([math]::Round($pageHeightPoints / 72.0, 3)) inches"
        Write-Host "Raster size per slide: $pixelWidth x $pixelHeight px at $Dpi DPI"
        Write-Host "Exporting $($presentation.Slides.Count) slide PNG(s)..."

        foreach ($slide in $presentation.Slides) {
            $slideNumber = [int]$slide.SlideNumber
            $pngPath = Join-Path $SlidesDir ("slide-{0:D4}.png" -f $slideNumber)
            $slide.Export($pngPath, "PNG", $pixelWidth, $pixelHeight)
            Write-Host "  slide $slideNumber -> $pngPath"
            [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($slide)
        }

        return [pscustomobject]@{
            PageWidthPoints = $pageWidthPoints
            PageHeightPoints = $pageHeightPoints
            PixelWidth = $pixelWidth
            PixelHeight = $pixelHeight
            SlideCount = [int]$presentation.Slides.Count
        }
    }
    finally {
        if ($null -ne $presentation) {
            $presentation.Close()
            [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($presentation)
        }
        if ($null -ne $powerPoint) {
            $powerPoint.Quit()
            [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($powerPoint)
        }

        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
    }
}

$resolvedPptx = Resolve-ExistingFile -Path $PptxPath
if ([System.IO.Path]::GetExtension($resolvedPptx).ToLowerInvariant() -ne ".pptx") {
    throw "Expected a .pptx file: $resolvedPptx"
}

if (-not (Test-Path -LiteralPath $PythonPath)) {
    $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
    if ($null -eq $pythonCommand) {
        throw "Python was not found. Pass -PythonPath with a Python executable that has Pillow installed."
    }
    $PythonPath = $pythonCommand.Source
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$builderPath = Join-Path $scriptDir "make_raw_image_pdf.py"
if (-not (Test-Path -LiteralPath $builderPath)) {
    throw "Missing helper script: $builderPath"
}

$pngCropperPath = Join-Path $scriptDir "crop_slide_pngs.py"
if (-not (Test-Path -LiteralPath $pngCropperPath)) {
    throw "Missing helper script: $pngCropperPath"
}

if ($KeepPortion -gt $TotalPortions) {
    throw "-KeepPortion cannot be greater than -TotalPortions."
}

if ([string]::IsNullOrWhiteSpace($PdfPath)) {
    $PdfPath = Get-DefaultPdfPath -ResolvedPptxPath $resolvedPptx
}

$resolvedPdf = [System.IO.Path]::GetFullPath($PdfPath)
$pdfDirectory = Split-Path -Parent $resolvedPdf
if (-not [System.IO.Directory]::Exists($pdfDirectory)) {
    [System.IO.Directory]::CreateDirectory($pdfDirectory) | Out-Null
}

$workDir = New-WorkDirectory -ResolvedPptxPath $resolvedPptx
$slidesDir = Join-Path $workDir "slides"
New-Item -ItemType Directory -Path $slidesDir -Force | Out-Null

Write-Host "Source PPTX: $resolvedPptx"
Write-Host "Target PDF:  $resolvedPdf"
Write-Host "Compression: $Compression"
Write-Warning "This creates a raster PDF. It avoids lossy PDF recompression, but text and vectors become high-resolution pixels."

try {
    $exportInfo = Export-SlidesToPng -ResolvedPptxPath $resolvedPptx -SlidesDir $slidesDir
    $pageWidthPoints = $exportInfo.PageWidthPoints

    if ($TotalPortions -gt 1) {
        Write-Host "Cropping exported PNG pixels to portion $KeepPortion of $TotalPortions before PDF assembly..."
        & $PythonPath $pngCropperPath `
            --slides-dir $slidesDir `
            --total-portions $TotalPortions `
            --keep-portion $KeepPortion

        if ($LASTEXITCODE -ne 0) {
            throw "The PNG cropper failed with exit code $LASTEXITCODE."
        }

        $pageWidthPoints = $exportInfo.PageWidthPoints / $TotalPortions
    }

    if (Test-Path -LiteralPath $resolvedPdf) {
        Remove-Item -LiteralPath $resolvedPdf -Force
    }

    $compressionArg = $Compression.ToLowerInvariant()
    & $PythonPath $builderPath `
        --slides-dir $slidesDir `
        --output $resolvedPdf `
        --page-width-points $pageWidthPoints `
        --page-height-points $exportInfo.PageHeightPoints `
        --compression $compressionArg

    if ($LASTEXITCODE -ne 0) {
        throw "The PDF builder failed with exit code $LASTEXITCODE."
    }

    if (-not (Test-Path -LiteralPath $resolvedPdf)) {
        throw "The PDF builder finished without creating the PDF."
    }

    $pdfItem = Get-Item -LiteralPath $resolvedPdf
    Write-Host "Done. PDF size: $([math]::Round($pdfItem.Length / 1MB, 2)) MB"
    Write-Host "Saved to: $resolvedPdf"

    if ($OpenAfterExport) {
        Start-Process -FilePath $resolvedPdf
    }
}
finally {
    if ($KeepSlidePngs) {
        Write-Host "Kept slide PNGs in: $slidesDir"
    }
    elseif (Test-Path -LiteralPath $workDir) {
        Remove-Item -LiteralPath $workDir -Recurse -Force
    }
}
