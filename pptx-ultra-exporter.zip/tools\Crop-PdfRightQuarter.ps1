<#
.SYNOPSIS
Crops each page of a PDF to the rightmost quarter of its width.

.DESCRIPTION
Use this when a PDF page is four side-by-side panels and you only want the
rightmost panel. The script updates PDF page boxes; it does not rasterize or
recompress images.

.EXAMPLE
.\Crop-PdfRightQuarter.ps1 -PdfPath "C:\path\wide.pdf"

.EXAMPLE
.\Crop-PdfRightQuarter.ps1 -PdfPath "C:\path\wide.pdf" -OutputPath "C:\path\right-panel.pdf"
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$PdfPath,

    [Parameter(Mandatory = $false, Position = 1)]
    [string]$OutputPath,

    [ValidateRange(1, 100)]
    [int]$TotalPortions = 4,

    [ValidateRange(1, 100)]
    [int]$KeepPortion = 4,

    [string]$PythonPath = "C:\Users\tumo0\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Resolve-ExistingFile {
    param([Parameter(Mandatory = $true)][string]$Path)

    $item = Get-Item -LiteralPath $Path -ErrorAction Stop
    if ($item.PSIsContainer) {
        throw "Expected a file, but got a directory: $Path"
    }

    return $item.FullName
}

function Get-DefaultOutputPath {
    param([Parameter(Mandatory = $true)][string]$ResolvedPdfPath)

    $directory = Split-Path -Parent $ResolvedPdfPath
    $name = [System.IO.Path]::GetFileNameWithoutExtension($ResolvedPdfPath)
    return Join-Path $directory "$name.rightmost-quarter.pdf"
}

if ($KeepPortion -gt $TotalPortions) {
    throw "-KeepPortion cannot be greater than -TotalPortions."
}

$resolvedPdf = Resolve-ExistingFile -Path $PdfPath
if ([System.IO.Path]::GetExtension($resolvedPdf).ToLowerInvariant() -ne ".pdf") {
    throw "Expected a .pdf file: $resolvedPdf"
}

if (-not (Test-Path -LiteralPath $PythonPath)) {
    $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
    if ($null -eq $pythonCommand) {
        throw "Python was not found. Pass -PythonPath with a Python executable that has pypdf installed."
    }
    $PythonPath = $pythonCommand.Source
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$cropperPath = Join-Path $scriptDir "crop_pdf_portion.py"
if (-not (Test-Path -LiteralPath $cropperPath)) {
    throw "Missing helper script: $cropperPath"
}

if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Get-DefaultOutputPath -ResolvedPdfPath $resolvedPdf
}

$resolvedOutput = [System.IO.Path]::GetFullPath($OutputPath)
$outputDirectory = Split-Path -Parent $resolvedOutput
if (-not [System.IO.Directory]::Exists($outputDirectory)) {
    [System.IO.Directory]::CreateDirectory($outputDirectory) | Out-Null
}

Write-Host "Source PDF: $resolvedPdf"
Write-Host "Output PDF: $resolvedOutput"
Write-Host "Keeping portion $KeepPortion of $TotalPortions"

& $PythonPath $cropperPath `
    --input $resolvedPdf `
    --output $resolvedOutput `
    --total-portions $TotalPortions `
    --keep-portion $KeepPortion

if ($LASTEXITCODE -ne 0) {
    throw "The PDF cropper failed with exit code $LASTEXITCODE."
}

$outputItem = Get-Item -LiteralPath $resolvedOutput
Write-Host "Done. PDF size: $([math]::Round($outputItem.Length / 1MB, 2)) MB"
Write-Host "Saved to: $resolvedOutput"
