import argparse
import os
import zlib
from pathlib import Path

from PIL import Image


def pdf_string(value):
    escaped = value.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    return f"({escaped})"


def pdf_name(value):
    safe = []
    for char in value:
        if char.isalnum() or char in "-_":
            safe.append(char)
        else:
            safe.append(f"#{ord(char):02X}")
    return "/" + "".join(safe)


class PdfWriter:
    def __init__(self):
        self.objects = []

    def add(self, body):
        self.objects.append(body)
        return len(self.objects)

    def render(self, root_object):
        chunks = [b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"]
        offsets = [0]

        for index, body in enumerate(self.objects, start=1):
            offsets.append(sum(len(chunk) for chunk in chunks))
            chunks.append(f"{index} 0 obj\n".encode("ascii"))
            if isinstance(body, bytes):
                chunks.append(body)
            else:
                chunks.append(body.encode("ascii"))
            chunks.append(b"\nendobj\n")

        xref_offset = sum(len(chunk) for chunk in chunks)
        chunks.append(f"xref\n0 {len(self.objects) + 1}\n".encode("ascii"))
        chunks.append(b"0000000000 65535 f \n")
        for offset in offsets[1:]:
            chunks.append(f"{offset:010d} 00000 n \n".encode("ascii"))

        trailer = (
            f"trailer\n<< /Size {len(self.objects) + 1} /Root {root_object} 0 R >>\n"
            f"startxref\n{xref_offset}\n%%EOF\n"
        )
        chunks.append(trailer.encode("ascii"))
        return b"".join(chunks)


def add_stream(pdf, dictionary, data):
    header = dictionary.replace("{length}", str(len(data))).encode("ascii")
    return pdf.add(header + b"\nstream\n" + data + b"\nendstream")


def load_rgb_bytes(path):
    with Image.open(path) as image:
        if image.mode in ("RGBA", "LA") or (
            image.mode == "P" and "transparency" in image.info
        ):
            rgba = image.convert("RGBA")
            background = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
            image = Image.alpha_composite(background, rgba).convert("RGB")
        else:
            image = image.convert("RGB")

        width, height = image.size
        return width, height, image.tobytes()


def build_pdf(image_paths, output_path, page_width_points, page_height_points, compression):
    pdf = PdfWriter()
    page_objects = []

    for index, image_path in enumerate(image_paths, start=1):
        width, height, rgb = load_rgb_bytes(image_path)
        image_data = rgb
        filter_line = ""

        if compression == "flate":
            image_data = zlib.compress(rgb, level=9)
            filter_line = "/Filter /FlateDecode "

        image_object = add_stream(
            pdf,
            (
                "<< /Type /XObject /Subtype /Image "
                f"/Width {width} /Height {height} "
                "/ColorSpace /DeviceRGB /BitsPerComponent 8 "
                f"{filter_line}/Length {{length}} >>"
            ),
            image_data,
        )

        content = (
            "q\n"
            f"{page_width_points:.4f} 0 0 {page_height_points:.4f} 0 0 cm\n"
            f"/Slide{index} Do\n"
            "Q\n"
        ).encode("ascii")
        content_object = add_stream(pdf, "<< /Length {length} >>", content)

        page_object = pdf.add(
            "<< /Type /Page /Parent {pages_parent} 0 R "
            f"/MediaBox [0 0 {page_width_points:.4f} {page_height_points:.4f}] "
            f"/Resources << /XObject << /Slide{index} {image_object} 0 R >> >> "
            f"/Contents {content_object} 0 R >>"
        )
        page_objects.append(page_object)

    pages_object = pdf.add(
        "<< /Type /Pages /Kids ["
        + " ".join(f"{page} 0 R" for page in page_objects)
        + f"] /Count {len(page_objects)} >>"
    )

    for page_object in page_objects:
        page_index = page_object - 1
        pdf.objects[page_index] = pdf.objects[page_index].replace(
            "{pages_parent}", str(pages_object)
        )

    catalog_object = pdf.add(f"<< /Type /Catalog /Pages {pages_object} 0 R >>")
    output_path.write_bytes(pdf.render(catalog_object))


def parse_args():
    parser = argparse.ArgumentParser(
        description="Build a PDF from slide PNGs using raw or lossless image streams."
    )
    parser.add_argument("--slides-dir", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--page-width-points", required=True, type=float)
    parser.add_argument("--page-height-points", required=True, type=float)
    parser.add_argument("--compression", choices=("raw", "flate"), default="raw")
    return parser.parse_args()


def main():
    args = parse_args()
    slides_dir = Path(args.slides_dir)
    output_path = Path(args.output)

    image_paths = sorted(
        slides_dir.glob("slide-*.png"),
        key=lambda path: int(path.stem.split("-")[-1]),
    )
    if not image_paths:
        raise SystemExit(f"No slide PNGs found in {slides_dir}")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    build_pdf(
        image_paths=image_paths,
        output_path=output_path,
        page_width_points=args.page_width_points,
        page_height_points=args.page_height_points,
        compression=args.compression,
    )

    size_mb = os.path.getsize(output_path) / (1024 * 1024)
    print(f"Wrote {output_path} ({size_mb:.2f} MB)")


if __name__ == "__main__":
    main()
