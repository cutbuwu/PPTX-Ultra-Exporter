import argparse
from pathlib import Path

import pypdf.filters
from pypdf import PdfReader, PdfWriter
from pypdf.generic import RectangleObject


BOX_NAMES = ("mediabox", "cropbox", "trimbox", "bleedbox", "artbox")
MAX_INTENTIONAL_STREAM_BYTES = 8 * 1024 * 1024 * 1024


pypdf.filters.MAX_DECLARED_STREAM_LENGTH = MAX_INTENTIONAL_STREAM_BYTES
pypdf.filters.MAX_ARRAY_BASED_STREAM_OUTPUT_LENGTH = MAX_INTENTIONAL_STREAM_BYTES
pypdf.filters.ZLIB_MAX_OUTPUT_LENGTH = MAX_INTENTIONAL_STREAM_BYTES


def crop_page_to_portion(page, total_portions, keep_portion):
    media = page.mediabox
    left = float(media.left)
    right = float(media.right)
    bottom = float(media.bottom)
    top = float(media.top)

    width = right - left
    portion_width = width / total_portions
    new_left = left + (keep_portion - 1) * portion_width
    new_right = left + keep_portion * portion_width
    cropped = RectangleObject([new_left, bottom, new_right, top])

    for box_name in BOX_NAMES:
        try:
            setattr(page, box_name, cropped)
        except Exception:
            pass

    return width, top - bottom, portion_width


def crop_pdf(input_path, output_path, total_portions, keep_portion):
    reader = PdfReader(str(input_path))
    writer = PdfWriter()

    if len(reader.pages) == 0:
        raise SystemExit("Input PDF has no pages.")

    first_dims = None
    for page_index, page in enumerate(reader.pages, start=1):
        dims = crop_page_to_portion(page, total_portions, keep_portion)
        if first_dims is None:
            first_dims = dims
        writer.add_page(page)
        print(f"Cropped page {page_index}")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("wb") as output_file:
        writer.write(output_file)

    width, height, portion_width = first_dims
    print(
        "Original first page: "
        f"{width:.2f} x {height:.2f} pt; "
        f"cropped width: {portion_width:.2f} pt"
    )


def parse_args():
    parser = argparse.ArgumentParser(
        description="Crop each PDF page to one equal-width horizontal portion."
    )
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--total-portions", type=int, default=4)
    parser.add_argument("--keep-portion", type=int, default=4)
    return parser.parse_args()


def main():
    args = parse_args()
    if args.total_portions < 1:
        raise SystemExit("--total-portions must be at least 1.")
    if args.keep_portion < 1 or args.keep_portion > args.total_portions:
        raise SystemExit("--keep-portion must be between 1 and --total-portions.")

    crop_pdf(
        input_path=Path(args.input),
        output_path=Path(args.output),
        total_portions=args.total_portions,
        keep_portion=args.keep_portion,
    )


if __name__ == "__main__":
    main()
