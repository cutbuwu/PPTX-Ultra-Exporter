const crypto = require("crypto");
const fs = require("fs");
const http = require("http");
const os = require("os");
const path = require("path");
const { spawn } = require("child_process");

const PORT = Number(process.env.PORT || 5177);
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, "public");
const TOOLS_DIR = path.join(ROOT, "tools");
const RUNS_DIR = path.join(ROOT, "runs");
const DOWNLOADS_DIR = path.join(os.homedir(), "Downloads");

fs.mkdirSync(RUNS_DIR, { recursive: true });
fs.mkdirSync(DOWNLOADS_DIR, { recursive: true });

const jobs = new Map();

function sendJson(res, status, data) {
  const body = Buffer.from(JSON.stringify(data));
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Content-Length": body.length,
  });
  res.end(body);
}

function sendText(res, status, text) {
  const body = Buffer.from(text);
  res.writeHead(status, {
    "Content-Type": "text/plain; charset=utf-8",
    "Content-Length": body.length,
  });
  res.end(body);
}

function contentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".html") return "text/html; charset=utf-8";
  if (ext === ".css") return "text/css; charset=utf-8";
  if (ext === ".js") return "text/javascript; charset=utf-8";
  if (ext === ".svg") return "image/svg+xml";
  if (ext === ".pdf") return "application/pdf";
  if (ext === ".png") return "image/png";
  return "application/octet-stream";
}

function serveStatic(req, res) {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const requested = url.pathname === "/" ? "/index.html" : url.pathname;
  const safePath = path.normalize(requested).replace(/^(\.\.[/\\])+/, "");
  const filePath = path.join(PUBLIC_DIR, safePath);

  if (!filePath.startsWith(PUBLIC_DIR)) {
    sendText(res, 403, "Forbidden");
    return;
  }

  fs.readFile(filePath, (error, data) => {
    if (error) {
      sendText(res, 404, "Not found");
      return;
    }

    res.writeHead(200, {
      "Content-Type": contentType(filePath),
      "Content-Length": data.length,
    });
    res.end(data);
  });
}

function parseMultipart(buffer, contentTypeHeader) {
  const match = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentTypeHeader || "");
  if (!match) throw new Error("Missing multipart boundary.");

  const boundary = Buffer.from(`--${match[1] || match[2]}`);
  const fields = {};
  const files = {};
  let offset = 0;

  while (offset < buffer.length) {
    const start = buffer.indexOf(boundary, offset);
    if (start === -1) break;
    const partStart = start + boundary.length;
    if (buffer.slice(partStart, partStart + 2).toString() === "--") break;

    const headerStart = partStart + 2;
    const headerEnd = buffer.indexOf(Buffer.from("\r\n\r\n"), headerStart);
    if (headerEnd === -1) break;

    const headers = buffer.slice(headerStart, headerEnd).toString("utf8");
    const nextBoundary = buffer.indexOf(boundary, headerEnd + 4);
    if (nextBoundary === -1) break;

    const body = buffer.slice(headerEnd + 4, nextBoundary - 2);
    const nameMatch = /name="([^"]+)"/.exec(headers);
    const fileMatch = /filename="([^"]*)"/.exec(headers);
    if (nameMatch) {
      const name = nameMatch[1];
      if (fileMatch && fileMatch[1]) {
        files[name] = {
          filename: path.basename(fileMatch[1]),
          data: body,
        };
      } else {
        fields[name] = body.toString("utf8");
      }
    }

    offset = nextBoundary;
  }

  return { fields, files };
}

function readBody(req, limitBytes = 1024 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;

    req.on("data", (chunk) => {
      total += chunk.length;
      if (total > limitBytes) {
        reject(new Error("Upload is too large."));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function runCommand(command, args, job, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd: ROOT,
      windowsHide: true,
      ...options,
    });

    child.stdout.on("data", (data) => {
      job.log += data.toString();
    });
    child.stderr.on("data", (data) => {
      job.log += data.toString();
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) resolve();
      else reject(new Error(`${command} exited with ${code}`));
    });
  });
}

function makeJob() {
  const id = crypto.randomBytes(8).toString("hex");
  const dir = path.join(RUNS_DIR, id);
  fs.mkdirSync(dir, { recursive: true });

  const job = {
    id,
    dir,
    state: "queued",
    log: "",
    outputName: null,
    outputUrl: null,
    error: null,
    createdAt: Date.now(),
  };
  jobs.set(id, job);
  return job;
}

function safeNumber(value, fallback, min, max) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.max(min, Math.min(max, parsed));
}

function safeOutputName(name) {
  return name.replace(/[<>:"/\\|?*\u0000-\u001f]/g, "_");
}

function uniquePath(directory, filename) {
  const parsed = path.parse(filename);
  let candidate = path.join(directory, filename);
  let index = 2;

  while (fs.existsSync(candidate)) {
    candidate = path.join(directory, `${parsed.name} (${index})${parsed.ext}`);
    index += 1;
  }

  return candidate;
}

async function handleExport(req, res) {
  const body = await readBody(req);
  const { fields, files } = parseMultipart(body, req.headers["content-type"]);
  const file = files.pptx;

  if (!file || !file.filename.toLowerCase().endsWith(".pptx")) {
    sendJson(res, 400, { error: "Upload a .pptx file." });
    return;
  }

  const job = makeJob();
  const baseName = path.basename(file.filename, path.extname(file.filename));
  const pptxPath = path.join(job.dir, file.filename);
  const pdfPath = path.join(job.dir, `${baseName}.ultra-raster.pdf`);
  fs.writeFileSync(pptxPath, file.data);

  const dpi = safeNumber(fields.dpi, 600, 72, 2400);
  const compression = fields.compression === "Flate" ? "Flate" : "Raw";
  const cropPortion = fields.cropPortion || "none";

  sendJson(res, 202, { jobId: job.id });

  queueMicrotask(async () => {
    try {
      job.state = "running";
      job.log += `Starting export at ${dpi} DPI with ${compression} compression.${os.EOL}`;

      await runCommand("powershell.exe", [
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        path.join(TOOLS_DIR, "Export-PptxUltraRasterPdf.ps1"),
        "-PptxPath",
        pptxPath,
        "-PdfPath",
        pdfPath,
        "-Dpi",
        String(dpi),
        "-Compression",
        compression,
        ...(cropPortion === "none" ? [] : [
          "-TotalPortions",
          "4",
          "-KeepPortion",
          String(safeNumber(cropPortion, 4, 1, 4)),
        ]),
      ], job);

      let finalPath = pdfPath;
      let finalName = `${baseName}.ultra-raster-${dpi}dpi.pdf`;
      if (cropPortion !== "none") {
        const keepPortion = safeNumber(cropPortion, 4, 1, 4);
        finalName = `${baseName}.portion-${keepPortion}-of-4.${dpi}dpi.pdf`;
        finalPath = path.join(job.dir, finalName);
        fs.renameSync(pdfPath, finalPath);
      }

      const downloadsPath = uniquePath(DOWNLOADS_DIR, safeOutputName(finalName));
      fs.copyFileSync(finalPath, downloadsPath);
      job.log += `${os.EOL}Saved a copy to Downloads: ${downloadsPath}${os.EOL}`;

      job.state = "done";
      job.outputName = path.basename(downloadsPath);
      job.outputUrl = `/download/${job.id}/${encodeURIComponent(job.outputName)}`;
      job.downloadsPath = downloadsPath;
    } catch (error) {
      job.state = "error";
      job.error = error.message;
      job.log += `${os.EOL}${error.stack || error.message}${os.EOL}`;
    }
  });
}

function handleJob(req, res) {
  const id = req.url.split("/").pop();
  const job = jobs.get(id);
  if (!job) {
    sendJson(res, 404, { error: "Job not found." });
    return;
  }

  sendJson(res, 200, {
    id: job.id,
    state: job.state,
    log: job.log,
    outputName: job.outputName,
    outputUrl: job.outputUrl,
    downloadsPath: job.downloadsPath,
    error: job.error,
  });
}

function handleDownload(req, res) {
  const parts = req.url.split("/").map(decodeURIComponent);
  const id = parts[2];
  const filename = parts.slice(3).join("/");
  const job = jobs.get(id);
  if (!job || !filename) {
    sendText(res, 404, "Not found");
    return;
  }

  const filePath = job.downloadsPath || path.join(job.dir, path.basename(filename));
  if (!fs.existsSync(filePath)) {
    sendText(res, 404, "Not found");
    return;
  }

  const stat = fs.statSync(filePath);
  res.writeHead(200, {
    "Content-Type": contentType(filePath),
    "Content-Length": stat.size,
    "Content-Disposition": `attachment; filename="${path.basename(filePath).replace(/"/g, "")}"`,
  });
  fs.createReadStream(filePath).pipe(res);
}

const server = http.createServer((req, res) => {
  Promise.resolve()
    .then(async () => {
      if (req.method === "POST" && req.url === "/api/export") {
        await handleExport(req, res);
        return;
      }
      if (req.method === "GET" && req.url.startsWith("/api/jobs/")) {
        handleJob(req, res);
        return;
      }
      if (req.method === "GET" && req.url.startsWith("/download/")) {
        handleDownload(req, res);
        return;
      }
      if (req.method === "GET") {
        serveStatic(req, res);
        return;
      }
      sendText(res, 405, "Method not allowed");
    })
    .catch((error) => {
      sendJson(res, 500, { error: error.message });
    });
});

server.listen(PORT, () => {
  console.log(`PPTX Ultra Exporter running at http://localhost:${PORT}`);
});
