@echo off
setlocal
cd /d "%~dp0"
echo Starting PPTX Ultra Exporter...
echo.
npm start
