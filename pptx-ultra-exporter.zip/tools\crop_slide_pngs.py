import argparse
from pathlib import Path

from PIL import Image


def crop_images(slides_dir, total_portions, keep_portion):
    image_paths = sorted(slides_dir.glob("slide-*.png"))
    if not image_paths:
        raise SystemExit(f"No slide PNGs found in {slides_dir}")

    for image_path in image_paths:
        with Image.open(image_path) as image:
            width, height = image.size
            portion_width = width // total_portions
            left = int(round((keep_portion - 1) * width / total_portions))
            right = int(round(keep_portion * width / total_portions))
            cropped = image.crop((left, 0, right, height))
            cropped.save(image_path, "PNG")
            print(
                f"Cropped {image_path.name}: "
                f"{width}x{height} -> {cropped.size[0]}x{cropped.size[1]}"
            )


def parse_args():
    parser = argparse.ArgumentParser(
        description="Crop exported slide PNGs to one equal-width horizontal portion."
    )
    parser.add_argument("--slides-dir", required=True)
    parser.add_argument("--total-portions", type=int, default=4)
    parser.add_argument("--keep-portion", type=int, default=4)
    return parser.parse_args()


def main():
    args = parse_args()
    if args.total_portions < 1:
        raise SystemExit("--total-portions must be at least 1.")
    if args.keep_portion < 1 or args.keep_portion > args.total_portions:
        raise SystemExit("--keep-portion must be between 1 and --total-portions.")

    crop_images(
        slides_dir=Path(args.slides_dir),
        total_portions=args.total_portions,
        keep_portion=args.keep_portion,
    )


if __name__ == "__main__":
    main()
