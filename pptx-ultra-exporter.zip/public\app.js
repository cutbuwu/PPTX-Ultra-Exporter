const form = document.querySelector("#exportForm");
const fileInput = document.querySelector("#pptxInput");
const dropzone = document.querySelector("#dropzone");
const fileTitle = document.querySelector("#fileTitle");
const fileMeta = document.querySelector("#fileMeta");
const exportButton = document.querySelector("#exportButton");
const appStatus = document.querySelector("#appStatus");
const jobLabel = document.querySelector("#jobLabel");
const logBox = document.querySelector("#logBox");
const downloadLink = document.querySelector("#downloadLink");

let pollTimer = null;

function formatBytes(bytes) {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value.toFixed(value >= 10 || unit === 0 ? 0 : 1)} ${units[unit]}`;
}

function setStatus(text) {
  appStatus.textContent = text;
}

function setFile(file) {
  if (!file) {
    fileTitle.textContent = "Choose a PPTX or drop it here";
    fileMeta.textContent = "PowerPoint must be installed on this Windows machine.";
    return;
  }

  fileTitle.textContent = file.name;
  fileMeta.textContent = `${formatBytes(file.size)} · ready to export`;
}

function stopPolling() {
  if (pollTimer) {
    clearInterval(pollTimer);
    pollTimer = null;
  }
}

async function pollJob(jobId) {
  const response = await fetch(`/api/jobs/${jobId}`);
  const job = await response.json();
  if (!response.ok) throw new Error(job.error || "Could not read job status.");

  logBox.textContent = job.log || "Starting...";
  logBox.scrollTop = logBox.scrollHeight;
  jobLabel.textContent = `Job ${job.id} · ${job.state}`;

  if (job.state === "done") {
    stopPolling();
    setStatus("Done");
    exportButton.disabled = false;
    if (job.downloadsPath) {
      jobLabel.textContent = `Saved to ${job.downloadsPath}`;
    }
    downloadLink.href = job.outputUrl;
    downloadLink.download = job.outputName;
    downloadLink.classList.remove("hidden");
  }

  if (job.state === "error") {
    stopPolling();
    setStatus("Error");
    exportButton.disabled = false;
    downloadLink.classList.add("hidden");
    logBox.textContent = `${job.log}\n${job.error || ""}`.trim();
  }
}

fileInput.addEventListener("change", () => setFile(fileInput.files[0]));

for (const eventName of ["dragenter", "dragover"]) {
  dropzone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropzone.classList.add("dragging");
  });
}

for (const eventName of ["dragleave", "drop"]) {
  dropzone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropzone.classList.remove("dragging");
  });
}

dropzone.addEventListener("drop", (event) => {
  const [file] = event.dataTransfer.files;
  if (!file) return;

  const transfer = new DataTransfer();
  transfer.items.add(file);
  fileInput.files = transfer.files;
  setFile(file);
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const file = fileInput.files[0];

  if (!file) {
    setStatus("Choose file");
    logBox.textContent = "Choose a .pptx first.";
    return;
  }

  stopPolling();
  downloadLink.classList.add("hidden");
  exportButton.disabled = true;
  setStatus("Exporting");
  jobLabel.textContent = "Uploading";
  logBox.textContent = "Uploading deck...";

  try {
    const data = new FormData(form);
    const response = await fetch("/api/export", {
      method: "POST",
      body: data,
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Export failed.");

    jobLabel.textContent = `Job ${result.jobId} · queued`;
    pollTimer = setInterval(() => {
      pollJob(result.jobId).catch((error) => {
        stopPolling();
        setStatus("Error");
        exportButton.disabled = false;
        logBox.textContent = error.message;
      });
    }, 1000);
    await pollJob(result.jobId);
  } catch (error) {
    stopPolling();
    setStatus("Error");
    exportButton.disabled = false;
    logBox.textContent = error.message;
  }
});
